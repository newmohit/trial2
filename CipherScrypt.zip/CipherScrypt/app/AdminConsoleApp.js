define(function(require) {
    var $ = require("jquery");
	var Mn = require('marionette');
	var _ = require("underscore");
	var MainLayoutView = require("./scripts/views/MainLayoutView");
	var LayoutView = require("./scripts/views/LayoutView");
	var App = Mn.Application.extend({
	  region: '#app-root-element',

	  onStart: function() {
		
		this.showView(new LayoutView());
	  }
	});
	return App;
});