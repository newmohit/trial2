requirejs.config({
    
    baseUrl: './app',
	
	waitSeconds:100,
   
    paths: {
        jquery: './lib/jquery-3.2.1.min',
		jqueryui: './lib/jquery-ui.min',
		underscore: './lib/underscore-min',
		backbone: './lib/backbone',
		'backbone.radio' : './lib/backbone.radio',
		marionette: './lib/backbone.marionette',
		'text': './lib/text',
		tpl : './lib/underscore-tpl'
    },
	
	shim: {
		underscore: {
			exports: '_'
		},
		jqueryui: {
			deps: ['jquery']
		},
		backbone: {
			exports: 'Backbone',
			deps: ['jquery', 'underscore']
		},
		marionette: {
			exports: 'Backbone.Marionette',
			deps: ['backbone','backbone.radio']
		},
		tpl: {
			deps: ['underscore','text']
		}
	},
	
	deps: ['jquery', 'underscore','text','tpl']
});

// Start the main app logic.
requirejs(['./AdminConsoleApp'],function(App) {
    //jQuery loaded and can be used here now.
	
	var myApp = new App();
	myApp.start();
});