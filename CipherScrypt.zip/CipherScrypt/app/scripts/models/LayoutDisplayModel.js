define(function(require) {
	var Backbone = require('backbone');
	var LayoutDisplayModel = Backbone.Model.extend({
		
		defaults: {
			keys : [
				{
					displayName : "Status",
					id : "h_status",
					className : ""
					
				},
				{
					displayName : "Host Management",
					id : "h_host_management",
					className : ""
				},	
				{
					displayName : "Configuration",
					id : "h_configuration",
					className : ""
				},
				{
					displayName : "Maintainance",
					id : "h_maintainance",
					className : ""
				},
				{
					displayName : "Reports",
					id : "h_reports",
					className : ""
				},
				{
					displayName : "Logs",
					id : "h_logs",
					className : ""
				}
			],

			values : {
				h_status : [
					{
						displayName : "Host(s)",
						id : "v_status_hosts",
						className : ""
						
					},
					{
						displayName : "System",
						id : "v_status_system",
						className : ""
					},	
					{
						displayName : "Network",
						id : "v_status_network",
						className : ""
					},
					{
						displayName : "HSM",
						id : "v_status_hsm",
						className : ""
					},
					{
						displayName : "Database",
						id : "v_status_database",
						className : ""
					}
				],
				h_host_management: [
					{
						displayName : "Host(s)",
						id : "v_host_hosts",
						className : ""
						
					}
				],	
				h_configuration: [
					{
						displayName : "Users",
						id : "v_configuration_users",
						className : ""
						
					},
					{
						displayName : "System",
						id : "v_configuration_system",
						className : ""
					},	
					{
						displayName : "Network",
						id : "v_configuration_network",
						className : ""
					},
					{
						displayName : "HSM",
						id : "v_configuration_hsm",
						className : ""
					},
					{
						displayName : "Database",
						id : "v_configuration_database",
						className : ""
					}
				],
				h_maintainance: [
					{
						displayName : "Users",
						id : "v_maintainance_hosts",
						className : ""
						
					},	
					{
						displayName : "Network",
						id : "v_maintainance_network",
						className : ""
					},
					{
						displayName : "HSM",
						id : "v_maintainance_hsm",
						className : ""
					},
					{
						displayName : "Database",
						id : "v_maintainance_database",
						className : ""
					},
					{
						displayName : "Cluster Nodes",
						id : "v_maintainance_cluster_node",
						className : ""
					}
				]
					
			}	
		},
		
		getHorizontalNavBar : function(){
			return this.get("keys");
		},
		
		getVeritcalNavBar : function(verticalNavBarId){
			return this.get("values")[verticalNavBarId];
		}

	});
	return LayoutDisplayModel;
});

