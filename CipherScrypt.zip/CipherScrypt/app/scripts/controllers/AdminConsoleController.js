define(function(require) {
    var $ = require("jquery");
	var Mn = require('marionette');
	var _ = require("underscore");
	var layoutTemplate = require('tpl!./../../templates/layout.html');
	var MyView = Mn.View.extend({
	  template: layoutTemplate
	});
});