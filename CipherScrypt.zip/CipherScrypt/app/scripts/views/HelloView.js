define(function(require) {
    var $ = require("jquery");
	var jqui = require("jqueryui");
	var _ = require("underscore");
	var tpl = require('tpl!./../../templates/layout.html');
	var Marionette = require('marionette');
	var HelloWorld = Marionette.View.extend({
	  template: tpl,
	  
	  onRender: function(){
		  debugger;
		  this.$el.find( "#date" ).datepicker();
		  //$( "#date" ).datepicker();
		  this.$el.find( "#tabs" ).tabs();
		}
	});
	return HelloWorld;
});
