define(function(require) {
    var $ = require("jquery");
	var _ = require("underscore");
	var tpl = require('tpl!./../../templates/layout.html');
	var Marionette = require('marionette');
	var HelloWorld = Marionette.View.extend({
		template: tpl,

		tagName : "table",
		initialize: function() {
			debugger;
			_.extend(this,this.options);
		},
	  
	  
	  
	  onRender: function(){
		  //debugger;
		  
		}
	});
	return HelloWorld;
});
