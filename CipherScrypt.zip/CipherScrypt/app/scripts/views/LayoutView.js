define(function(require) {
    var $ = require("jquery");
	var tpl = require('tpl!./../../templates/site_layout.html');
	var Marionette = require('marionette');
	var LoginView = require('./LoginView');
	var MainLayoutView = require('./MainLayoutView');
	var LayoutView = Marionette.View.extend({
		template: tpl,
		
		className: 'layout-view',
		
		regions: {
			viewArea : '.view-area'
		},
		
		childViewEvents: {
			'uservalidated': '_userValidate'
		},
		
		initialize: function() {
			this.currentView = new MainLayoutView();
			
		},
		
		_userValidate : function(){
			debugger;
			this.currentView.destroy();
			this.currentView = new MainLayoutView();
			this.showChildView('viewArea',this.currentView);
		},
		
	  
		onRender: function(){
			//debugger;
			this.showChildView('viewArea',this.currentView);
		}
	});
	return LayoutView;
});
