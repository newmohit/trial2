define(function(require) {
    var $ = require("jquery");
	var tpl = require('tpl!./../../templates/login1.html');
	var Marionette = require('marionette');
	var LoginView = Marionette.View.extend({
		template: tpl,
		
		tagName: 'form',
		
		className: 'login-view',
		
		attributes: {
			action: ""
		},
		
		ui: {
			username: '#username',
			passwd: '#passwd',
			loginButton : "#login-button"
		},
		
		events:{
			"click @ui.loginButton" : "_validateForm"
		},
		
		_validateForm: function(){
			var x = this.$el[0];
			/*if(x.checkValidity()){
				debugger;
				var username = this.ui.username.val();
				var passwd = this.ui.passwd.val();
			}else{
				debugger;
			}*/
			
			if(x.reportValidity()){
				debugger;
				var username = this.ui.username.val();
				var passwd = this.ui.passwd.val();
				var promise = $.ajax({
					url : "/asd",
					type : "POST",
					data : {
						username : username,
						possword : passwd,
					}
				});
				//promise.resolve(true);
				promise.always(function(response){
					debugger;
					this.trigger("uservalidated");
				}.bind(this));	
			}
		},
		
		initialize: function() {
			
		},
		
	  
		onRender: function(){
			//debugger;
			
		}
	});
	return LoginView;
});
