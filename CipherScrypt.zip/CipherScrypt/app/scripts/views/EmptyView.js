define(function(require) {
    var $ = require("jquery");
	var jqui = require("jqueryui");
	var tpl = require('tpl!./../../templates/site_layout.html');
	var Marionette = require('marionette');
	var LayoutView = Marionette.View.extend({
		template: tpl,
		model : new LayoutDisplayModel(),
		
		regions: {
			verticalsViewArea : '#layout_verticals_view_area'
		},
		
		initialize: function() {
			this.currentVerticalView = new HelloView();
		},
			
		_updateVerticalView : function(event){
			debugger;
			var verticalNavBar = this.$el.find("ul#layout_vertical_nav_bar");
			verticalNavBar.empty();
			
			var verticalModel = this.model.getVeritcalNavBar(event.currentTarget.id);

			for(var j = 0; j < verticalModel.length ; j++){
				verticalNavBar.append("<li class='vertical_nav' id='" + verticalModel[j]['id'] + "'><a> " + verticalModel[j]['displayName'] +"</a></li>");	
			}
		},
		
		_loadNewDetailView : function(event){
			debugger;
		},
		
	  
		onRender: function(){
			//debugger;
			this.$el.find("ul#layout_horizontal_nav_bar");
			var horizontalModel = this.model.getHorizontalNavBar();
			for(var i = 0; i < horizontalModel.length; i++){
				this.$el.find("ul#layout_horizontal_nav_bar")
				.append("<li class='horizontal_nav' id='" + horizontalModel[i]['id'] + "'><a> " + horizontalModel[i]['displayName'] +"</a></li>");
			}

			var event = {
				currentTarget : {
					id : "h_status"
				}
			};
			
			this._updateVerticalView(event);
			this.showChildView('verticalsViewArea', this.currentVerticalView);
		}
	});
	return LayoutView;
});
